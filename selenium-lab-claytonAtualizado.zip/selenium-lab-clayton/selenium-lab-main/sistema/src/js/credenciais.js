// Aquivo contendo o usuário e senha validos para acessar o sistema.
let usuarioValido = {
    email: 'admin@admin.com',
    senha: 'admin@123'
};